﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace project
{
    /// <summary>
    /// Логика взаимодействия для soft.xaml
    /// </summary>
    public partial class soft : Window
    {
       
        public soft(string data)
        {
            InitializeComponent();
            UserLogin.Text = $"{data}";
            string data2 = data;
            
        }

        private void createEvents_Click(object sender, RoutedEventArgs e)
        {
            string data2 = UserLogin.Text;
            create_event create_Event = new create_event(data2);
            create_Event.Show();
            this.Close();
        }

        private void MyEvents_Click(object sender, RoutedEventArgs e)
        {
            string data2 = UserLogin.Text;
            YouEvents youEvents = new YouEvents(data2);
            youEvents.Show();
            this.Close();
        }

        private void chatButton_Click(object sender, RoutedEventArgs e)
        {
            string data2 = UserLogin.Text;
            chat chat = new chat(data2);
            chat.Show();
            this.Close();
        }

        private void eventchoice_Click(object sender, RoutedEventArgs e)
        {
            string data2 = UserLogin.Text;
            EventChoice eventChoice = new EventChoice(data2);
            eventChoice.Show();
            this.Close();
        }
    }
}
