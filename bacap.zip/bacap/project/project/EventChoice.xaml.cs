﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace project
{
    /// <summary>
    /// Логика взаимодействия для EventChoice.xaml
    /// </summary>
    /// 



    public class Event
    {
        public string Date { get; set; } = "";
        public string EventsName { get; set; } = "";
        
    }
    public class DataBaseService
    {



    }
    public partial class EventChoice : Window
    {
        public EventChoice(string data)
        {
            
            InitializeComponent();
            string log = data;
            lable.Text = log;

           
            string searchEvent = $"SELECT EventName, EventDate FROM CampSearchEvents";
            string connectionString = "Server=DESKTOP-C87AOAO;Database=CampSearch;Trusted_Connection=True;";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(searchEvent, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    events.ItemsSource = new Event[]
                    {

                    };



                }

            }
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            string log = lable.Text;
            soft soft = new soft(log);
            soft.Show  ();
            this.Close ();
        }

        private void events_TextInput(object sender, TextCompositionEventArgs e)
        {
            string log = lable.Text;
            string searchEvent = $"SELECT EventName, EventDate FROM CampSearchEvents" ;
            string connectionString = "Server=DESKTOP-C87AOAO;Database=CampSearch;Trusted_Connection=True;";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open ();
                SqlCommand command = new SqlCommand(searchEvent, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read()) 
                {
                    events.Text = reader.GetString(0);



                }

            }
        }

        private void acces_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
