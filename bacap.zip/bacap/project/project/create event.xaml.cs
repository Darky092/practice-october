﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace project
{
    /// <summary>
    /// Логика взаимодействия для create_event.xaml
    /// </summary>
    public partial class create_event : Window
    {
        public create_event(string data)
        {
            InitializeComponent();
            string log = data;
            lable.Text = log;
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            string log = lable.Text;
            soft soft = new soft(log);
            soft.Show();
            this.Close();
         
        }

        public async void CreateEvent_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                await znach();
            }
            catch { CreateEvent.Content = "чтото пошло не так"; }

        }
         async Task znach()
        {
            string date = DateTimeee.Text;
            DateTime dataTime;
            DateTime.TryParse(date, out dataTime);
            string formattedDate = dataTime.ToString("ddMMyy HH:mm:ss");
            string mark = Mark.Text.Trim();
            string peopleCount = PeopleCount.Text.Trim();
            string Id = "";
            string log = lable.Text.Trim();
            //string Insert = $"Insert into CampSearchEvents (UserCode, EventName, PeopleAmounth, EventDate) Values ('{Id}','{mark}','{peopleCount}','{dataTime}'";
            string searchId = $"SELECT * FROM CampSearchUsers Where Username = '{log}'";
            string connectionString = "Server=DESKTOP-C87AOAO;Database=CampSearch;Trusted_Connection=True;";
             await using (SqlConnection connection = new SqlConnection(connectionString))
             {
                SqlCommand searchUserIdQuare = new SqlCommand(searchId, connection);



                await connection.OpenAsync();
                SqlDataReader reader = searchUserIdQuare.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();
                    object userId = reader.GetValue(0);
                    Id = $"{userId}";
                    connection.Close();

                }
                SqlCommand eventInsert = new SqlCommand();
                await connection.OpenAsync();
                eventInsert.CommandText = $"Insert into CampSearchEvents (UserCode, EventName, PeopleAmounthMax, EventDate) Values ({Id},'{mark}',{peopleCount},'{formattedDate}')";
                eventInsert.Connection = connection;
                await eventInsert.ExecuteNonQueryAsync();
                connection.Close();

             }
            CreateEvent.Content = "эвент добавлен";
        }
    }
}
