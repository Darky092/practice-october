﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Navigation;

namespace project
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {

        public Window1()
        {
            InitializeComponent();
            
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void acces_Click(object sender, RoutedEventArgs e)
        {
            
            string pass = password.Text;
            string userEmail = email.Text;
            string connectionString = "Server=DESKTOP-C87AOAO;Database=CampSearch;Trusted_Connection=True;";
            string query = $"SELECT * FROM CampSearchUsers WHERE UserEmail = '{userEmail}'  AND UserPassword = '{pass}'";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                 
                connection.Open();
               
                SqlCommand command = new SqlCommand(query, connection);                
                SqlDataReader reader = command.ExecuteReader();
                if (reader.HasRows)
                {
                    reader.Read();                 
                    object name = reader.GetValue(1);
                    string serName = $"{name}";                   
                    soft soft = new soft(serName);
                    soft.Show();
                    this.Close();                                                     
                    connection.Close();
                }
                else
                {
                    nammer.Text = "Неверный л or п";
                    connection.Close();
                }

            }

        }
    }
}
