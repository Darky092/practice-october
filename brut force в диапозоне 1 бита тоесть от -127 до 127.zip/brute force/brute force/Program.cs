﻿using System.Security.Cryptography;
using System.Text;

namespace brute_force
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string password =md5.hashPassword(Password());
            Random rnd = new Random();
            byte[] bytes = new byte[1000];
            rnd.NextBytes(bytes);
            Console.WriteLine("Five random byte values:");
            string a = "";
            if (password == Convert.ToString(a))
            {
                Console.WriteLine($"вы нашли {a}");
            }
            else
            {
                foreach (byte byteValue in bytes)
                    for (int i = 0; i < byte.MaxValue; i++)
                    {
                        a = md5.hashPassword(Convert.ToString(byteValue));
                        Console.Write("{0, 5}", a);
                        Console.WriteLine();
                        if (a == password) { break; }
                    }
                Console.WriteLine($"Ваш пароль{a}");
                Console.ReadLine();
            }          

        }

        static string Password()
        {
            string a = Console.ReadLine();
            return a;
        }

    }
    class md5
    {


        public static string hashPassword(string password)
        {
            MD5 md5 = MD5.Create();
            byte[] b = Encoding.ASCII.GetBytes(password);
            byte[] hash = md5.ComputeHash(b);
            StringBuilder sb = new StringBuilder();
            foreach (var a in hash)
                sb.Append(a.ToString("X2"));

            return Convert.ToString(sb);
        }
    }
}
