create table Enjoyers
(
EnjoyerCode int not null primary key identity (1,1),
EventCode int not null
foreign key (EventCode) references CampSearchEvents (EventCode)ON DELETE CASCADE ON UPDATE CASCADE,
Age int not null,
RealName nvarchar not null,
Surname nvarchar(max) not null
)