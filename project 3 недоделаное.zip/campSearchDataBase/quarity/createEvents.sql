create table CampSearchEvents
(
EventCode int not null primary key identity (1,1),
UserCode int not null
foreign key (UserCode) references CampSearchUsers (UserCode)ON DELETE CASCADE ON UPDATE CASCADE,
EventName nvarchar (max) not null,
PeopleAmounthMax int not null,
EventDate datetime not null,
Conditions nvarchar(max) null
)