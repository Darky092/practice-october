create table CampSearchUsers
(
UserCode int Primary key  IDENTITY (1,1), 
Username nvarchar(70) not null,
UserPassword nvarchar (max) not null,
UserEmail nvarchar (max) not null,
)