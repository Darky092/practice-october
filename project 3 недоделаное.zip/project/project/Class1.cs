﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;

namespace project
{
    class Class1
    {

        private int UserCose {  get; set; }
        private string UserName, UserPassword, UserEmail;

       public Class1() { }
       public Class1 (string Username, string UserPassword, string UserEmail)
        {
            this.UserName = Username;
            this.UserPassword = UserPassword;
            this.UserEmail = UserEmail;



          
        }
    

        





    }
}
