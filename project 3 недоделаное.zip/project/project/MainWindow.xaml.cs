﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string connectionString;
        SqlDataAdapter adapter;
        DataTable CampSearchUsersTable;
        string username;
        string password;
        string email;
        string cheak;
        public MainWindow()
        {
            InitializeComponent();
            connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        }

        private void accaunt_Click(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();           
            window1.Show();
            this.Close();
        }


        private void registration_Click(object sender, RoutedEventArgs e)
        {
         username = Login.Text.Trim();
         password = Password.Text.Trim();
         email = Email.Text.Trim();
         cheak = repiatPassword.Text.Trim();
           
            if (username.Length > 5 && password.Length > 5 && cheak == password && email.Contains("@"))
            {
                Window1 window1 = new Window1();
                window1.Show();
                this.Close();
            }
            else if (username.Length <= 5)
            {
             cheklog.Text = "Логин должен содержать больше 5 символоф";
                Login.Text = "";
            }
            else if (password.Length <= 5)
            {
             checkpas.Text = "Пароль должен содержать больше 5 символоф";
                Password.Text = "";
            }
            else if (cheak != password)
            {
                Password.Text = "Данные введены некоректно";
                repiatPassword.Text = "Данные введены некоректно";
            }
            else if (email.Contains("@") == false)
            {
                emailchek.Text = "Данные введены не коректно";
            }

    

        }
    }
}