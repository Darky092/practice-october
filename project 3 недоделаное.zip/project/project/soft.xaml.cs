﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace project
{
    /// <summary>
    /// Логика взаимодействия для soft.xaml
    /// </summary>
    public partial class soft : Window
    {
        public soft()
        {
            InitializeComponent();
        }

        private void createEvents_Click(object sender, RoutedEventArgs e)
        {
            create_event create_Event = new create_event();
            create_Event.Show();
            this.Close();
        }

        private void MyEvents_Click(object sender, RoutedEventArgs e)
        {
            YouEvents youEvents = new YouEvents();
            youEvents.Show();
            this.Close();
        }
    }
}
