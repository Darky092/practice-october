﻿using System.Data.SqlClient;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.ComponentModel;

namespace Project_4
{
    internal class Program
    {


        static async Task Main(string[] args)
        {
            Console.Clear();
            Console.WriteLine("Работа с таблицей CampSearchUsers \nЧто ты хочешь сделать? \n1) Посмотреть все записи\n2) Добавить нового пользователя\n3) Обновить существеющего пользователя \n4) Удалить существующего пользователя");
            string connectionString = "Server=DESKTOP-C87AOAO;Database=CampSearch;Trusted_Connection=True;";
            int choice;
            string AddUser = "";
            choice = Choice();
            if (choice == 1)
            {
                string query = "SELECT * FROM CampSearchUsers";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    try
                    {
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            Console.Write($"{reader.GetName(i),-20}");
                        }
                        Console.WriteLine();
                        while (reader.Read())
                        {
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                Console.Write($"{reader[i],-20}");
                            }
                            Console.WriteLine();
                        }
                        reader.Close();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("erorr");
                    }
                    Console.WriteLine("Нажми любую кнопку чтобы вернуться");
                    Console.ReadLine();
                    Main(args);
                }
            }
            else if (choice == 2)
            {
                Console.Clear();
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        Console.WriteLine("Напиши через запятую, в ковычках 'username', 'userpassword', 'useremail'");
                        AddUser = NewYser();
                        await connection.OpenAsync();
                        SqlCommand viewData = new SqlCommand();
                        viewData.CommandText = $"Insert into CampSearchUsers (UserName, UserPassword, UserEmail) VALUES ({AddUser}) ";
                        viewData.Connection = connection;
                        await viewData.ExecuteNonQueryAsync();
                        Console.WriteLine("User добавлен");
                    }
                    catch
                    {
                        Console.WriteLine("error");
                    }
                }
                Console.WriteLine("Нажми любую кнопку чтобы вернуться");
                Console.ReadLine();
                Main(args);
            }
            else if (choice == 3)
            {
                Console.Clear();
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        Console.WriteLine("Сначало напиши новый username затем нажми enter, потом новый парроль enter, потом новый адресс эл.почты enter, далее укажи юзер код пользователя которого хочешь поменять ");
                        string addName = NewYser();
                        string addPass = NewYser();
                        string addEmail = NewYser();
                        int userCode = Choice();
                        await connection.OpenAsync();
                        SqlCommand command = new SqlCommand();
                        command.CommandText = $"Update CampSearchUsers set UserName = '{addName}', UserPassword = '{addPass}', UserEmail = '{addEmail}' Where UserCode = {userCode}; ";
                        command.Connection = connection;
                        int number = await command.ExecuteNonQueryAsync();
                        Console.WriteLine($"Обновил, проверяй \nДобавлено строк {number} ");
                    }
                    catch { Console.WriteLine("error"); }
                }
                Console.WriteLine("Нажми любую кнопку чтобы вернуться");
                Console.ReadLine();
                Main(args);

            }
            else if (choice == 4)
            {
                Console.Clear();
                Console.WriteLine("Напиши код пользователя которого хочешь удалить");
                try
                {
                    int userCodetwo = Choice();
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        await connection.OpenAsync();
                        SqlCommand deleteUsern = new SqlCommand();
                        deleteUsern.CommandText = $"DELETE FROM CampSearchUsers WHERE UserCode = {userCodetwo};";
                        deleteUsern.Connection = connection;
                        int number = await deleteUsern.ExecuteNonQueryAsync();
                        Console.WriteLine($"Удалено строк {number}");
                    }


                }catch { Console.WriteLine("error"); }
            }
            Console.WriteLine("Нажми любую кнопку чтобы вернуться");
            Console.ReadLine();
            Main(args);
        }


        static int Choice()
        {
            int a;
            a = Convert.ToInt32(Console.ReadLine());
            return a;
        }
        static string NewYser()
        {
            string a = Console.ReadLine();
            return a;
        }





        //КОД КОТОРЫЙ НИЖЕ НЕ ЗА ЧТО НЕ ОТВЕЧАЕТ ОН ЗДЕСЬ ТОЛЬКО ДЛЯ ПРАКТИКИ МЕТОДОВ КЛАССОВ И КОНСТРУКТОРОВ SQL NUGET ПАКА.!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        static async Task MaineTwo()
        {
            Console.Clear ();

           int choice;
           string connectionString = "Server=DESKTOP-C87AOAO;Database=CampSearch;Trusted_Connection=True;";
            string AddUser = "";
            string addPass = "";
           string addName = "";
            string addEmail = "";
            int userCode = 0;
           string sqlExpressionOne = "SELECT* FROM CampSearchUsers";
            string sqlExpressionTwo = $"Insert into CampSearchUsers (UserName, UserPassword, UserEmail) VALUES ({AddUser}) ";
           string sqlExpressionThree = $"Update CampSearchUsers set UserName '{addName}', UserPassword '{addPass}', UserEmail '{addEmail}' Where UserCode = {userCode}; ";
            string sqlExpressionFour = $"DELETE FROM CampSearchUsers WHERE UserCode = {userCode}; ";



            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                Console.WriteLine("Работа с таблицей CampSearchUsers \nЧто ты хочешь сделать? \n1) Посмотреть все записи\n2) Добавить нового пользователя\n3) Обновить существеющего пользователя \n4) Удалить существующего пользователя");

                choice = Choice();

                if (choice == 1)
                {
                    Console.Clear();
                    try
                    {
                        await connection.OpenAsync();
                        SqlCommand viewData = new SqlCommand();
                        viewData.CommandText = "SELECT* FROM CampSearchUsers";
                        viewData.Connection = connection;
                        await viewData.ExecuteReaderAsync();



                    }
                    catch
                    {
                        Console.WriteLine("Error");
                    }
                }
                else if (choice == 2)
                {
                    Console.Clear();
                    try
                    {
                        Console.WriteLine("Напиши через запятую username, userpassword, useremail");
                        AddUser = NewYser();
                        await connection.OpenAsync();
                        SqlCommand addNewUser = new SqlCommand(sqlExpressionTwo, connection);
                        int number = await addNewUser.ExecuteNonQueryAsync();
                        Console.WriteLine($"Добавлено обьектов {number}\nНажми на любую клавишу чтобы вернуться обратно");
                        Console.ReadLine();
                        



                    }
                    catch 
                    {
                        Console.WriteLine("Error");
                    }

                }
                else if (choice == 3)
                {
                    Console.Clear();
                    try
                    {
                        Console.WriteLine("Напиши код пользователя которого хочешь обновить");
                        userCode = Choice();
                        Console.WriteLine("Напиши Username");
                        addName = NewYser();
                        Console.WriteLine("Напиши Userpassword");
                        addPass = NewYser();
                        Console.WriteLine("Напиши UserEmail");
                        addEmail = NewYser();



                        await connection.OpenAsync();
                        SqlCommand updateUser = new SqlCommand(sqlExpressionThree, connection);
                        updateUser.CommandText = "";
                        updateUser.Connection = connection;















                    }
                    catch 
                    { 
                        Console.WriteLine("Error"); 
                    }
                }
                else if (choice == 4)
                {
                    Console.Clear();
                    try
                    {
                        Console.WriteLine("Напиши код пользователя которого хочешь удалить");
                        userCode = Choice();
                      
                        await connection.OpenAsync();
                        SqlCommand deleteUsern = new SqlCommand(sqlExpressionFour, connection);
                        deleteUsern.CommandText = "";
                        deleteUsern.Connection = connection;
                    }
                    catch 
                    {
                        Console.WriteLine("Error");
                    }
                }
            }





        }




        /*        static async Task Main(string[] args)
        {
            Console.WriteLine("Работа с таблицей CampSearchUsers \nЧто ты хочешь сделать? \n1) Посмотреть все записи\n2) Добавить нового пользователя\n3) Обновить существеющего пользователя \n4) Удалить существующего пользователя");
            string connectionString = "Server=DESKTOP-C87AOAO;Database=CampSearch;Trusted_Connection=True;";
            int choice;
            string AddUser = "";
            choice = Choice();
            if (choice == 1) 
            { 
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                    AddUser = NewYser();
                await connection.OpenAsync();
                    
                SqlCommand command = new SqlCommand();
                command.CommandText = $"Insert into CampSearchUsers (UserName, UserPassword, UserEmail) VALUES ({AddUser}) ";
                    command.Connection = connection;
                await command.ExecuteNonQueryAsync();

                Console.WriteLine("Таблица Users создана");
            }
            Console.Read();

            }






        }*/


    }

}

