﻿using System.ComponentModel.Design;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace Хэширование_паролей_в_базу_данных_sql
{
    internal class Program
    {


        static void Main(string[] args)
        {
            Console.Clear();
            string connectionString = "Server=DESKTOP-C87AOAO;Database=Хэширвоание паролей;Trusted_Connection=True;";
            Console.WriteLine("Добро пожаловать в приложение\n Нажмите 1 чтобы войти \n нажмите 2 чтобы создать нового пользователя\n Нажмите 3 чтобы посмотреть пользователей в сети");
            int a = choice();
            string login = "";
            var password = "";
            string email = "";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                if (a == 0) { Main(args); }
                else if (a == 1)
                {

                    //сначало сделаем без сольника                 
                    Console.WriteLine("Введите сначало логин затем пароль затем емаил");
                    login = Console.ReadLine();
                    Console.Clear();
                    // password = md5.hashPassword(Input());
                    //теперь сделаем с какимнибудь сольником
                    string b = Input();
                    string c = b;
                    password = md5.hashPassword(b + "sssaaa" + c + "laks");
                    Console.Clear();
                    email = Console.ReadLine();
                    Console.Clear();
                    connection.Open();
                    string logInQuary = $"Select UserId from heshPass where login = '{login}' and password ='{password}' and email ='{email}'";
                    SqlCommand logIn = new SqlCommand(logInQuary, connection);
                    SqlDataReader reader = logIn.ExecuteReader();
                    if (reader.HasRows)
                    {
                        reader.Read();
                        object userId = reader.GetValue(0);
                        string ud = Convert.ToString(userId);
                        connection.Close();
                        Console.WriteLine($"Добро пожаловать {login}.\n Ваш UserId = {ud}");
                        Console.ReadLine();
                        Main(args);
                    }
                    else { Console.WriteLine("Вы ввели неправильный логин или пароль"); }




                }
                else if (a == 2)
                {
                    Console.WriteLine("Напиши логин, затем пароль, затем емаил");
                    login = Input();
                    Console.Clear();
                    //password = md5.hashPassword(Input());
                    string b = Input();
                    string c = b;
                    password = md5.hashPassword(b + "sssaaa" + c + "laks");
                    Console.Clear();
                    email = Input();
                    Console.Clear();
                    connection.Open();
                    SqlCommand logInsert = new SqlCommand();
                    logInsert.CommandText = $"Insert into heshPass (login, password, email) values ('{login}','{password}','{email}')";
                    logInsert.Connection = connection;
                    logInsert.ExecuteNonQuery();
                    connection.Close();
                    Console.ReadLine();
                    Main(args);
                }
                else if (a == 3)
                {
                    string allUsersQuary = "SELECT login, UserId FROM heshPass";
                    string pp = "***********";
                    connection.Open();
                    SqlCommand allUs = new SqlCommand(allUsersQuary, connection);
                    SqlDataReader readAllUser = allUs.ExecuteReader();
                    if (readAllUser.HasRows)
                    {
                        Console.WriteLine($"{"password",-60}");
                        for (int i = 0; i < readAllUser.FieldCount; i++)
                        {
                        
                            Console.WriteLine($"{readAllUser.GetName(i),-20}");
                        }
                        
                        Console.WriteLine();
                        
                        while (readAllUser.Read())
                        {
                            int i = 0;
                            int l = 1;
                            for(i = 0; i < readAllUser.FieldCount; i++,l++)
                            {
                                for (int b = 0 ;b< l/2;b++)
                                {
                                    Console.WriteLine($"{pp,-60}");
                                }
                                Console.WriteLine($"{readAllUser[i], -20}");
                                
                            }
                            Console.WriteLine();
                        }
                        Console.ReadLine() ;

                    }

                }
            }


            static int choice()
            {
                int a = Convert.ToInt32(Console.ReadLine());
                return a;
            }
            static string Input()
            {
                string a = Console.ReadLine();
                return a;
            }



        }
        class md5
        {


            public static string hashPassword(string password)
            {
                MD5 md5 = MD5.Create();
                byte[] b = Encoding.ASCII.GetBytes(password);
                byte[] hash = md5.ComputeHash(b);
                StringBuilder sb = new StringBuilder();
                foreach (var a in hash)
                    sb.Append(a.ToString("X2"));

                return Convert.ToString(sb);
            }
        }
    }
}
