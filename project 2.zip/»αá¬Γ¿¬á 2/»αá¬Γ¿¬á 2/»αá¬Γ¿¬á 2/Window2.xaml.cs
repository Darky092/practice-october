﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace практика_2
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
       
            InitializeComponent();
        }

        private void obratno_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
        Random rnd = new Random();
        string p;

        private void znak_TextChanged(object sender, TextChangedEventArgs e)
        {
            p = znak.Text;
        }
        double znacheni1;
        double znacheni2;

        private void random_Click(object sender, RoutedEventArgs e)
        {
            number1.Text = Convert.ToString(rnd.Next(0, 100));
            znacheni1 = Convert.ToDouble(number1.Text);
            number2.Text = Convert.ToString(rnd.Next(0,100));
            znacheni2 = Convert.ToDouble(number2.Text);
        }

        double otvet = 0;

        private void start_Click(object sender, RoutedEventArgs e)
        {
            switch (p)
            {
                case "+":
                    otvet = znacheni1 + znacheni2;
                    tb.Text = Convert.ToString(otvet);
                    break;
                case "-":
                    otvet = znacheni2 - znacheni1;
                    tb.Text = Convert.ToString(otvet);
                    break;
                case "*":
                    otvet = znacheni1 * znacheni2;
                    tb.Text = Convert.ToString(otvet);
                    break;
                case "/":
                    otvet = znacheni2 / znacheni1;
                    tb.Text = Convert.ToString(otvet);
                    break;
                default:
                    tb.Text = "ERROR!!!!!!!!!!!";
                    break;
            }
        }
    }
}



