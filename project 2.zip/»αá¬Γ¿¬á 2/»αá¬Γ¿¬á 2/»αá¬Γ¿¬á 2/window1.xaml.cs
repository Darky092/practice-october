﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace практика_2
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            
        }
        Dictionary<string, string> weather = new Dictionary<string, string>()
        {
            {"солнечно", "sunny"},
            {"ветренно", "windy"},
            {"туманно", "foggy"},
            {"темно", "dark"},
            {"холодно", "cold"},
            {"тепло", "warm"},
            {"дождь", "rain"},
            {"ураган", "storm"},
            {"погода", "weather"},
            {"жарко", "sunny"},
        };
          private void vozvrat_Click(object sender, RoutedEventArgs e)
        {
          MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
        string emty = "";


        private void russia_TextChanged(object sender, TextChangedEventArgs e)
        {
            emty = russia.Text.ToLower();
        }

        private void perevesty_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                english.Text = weather[emty];
            }
            catch
            {
                english.Text = "error";
            }
        }
    }
}
