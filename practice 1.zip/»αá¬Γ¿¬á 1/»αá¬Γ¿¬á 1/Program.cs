﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace перевод_шкал

{
    internal class Program
    {

        static void Main(string[] args)
        {
            Menu();
        }
        static void Menu()
        {
            Console.WriteLine("Выберите номер задания  1-10");
            string a = Console.ReadLine();
            switch (a)
            {
                case "1":
                    Console.WriteLine("Разработайте программу которая принимае четыре числа и находит среднее значение между ними\nНажмите на любой символ чтобы продолжить");
                    Console.ReadLine();
                    Middle();
                    break;
                case "2":
                    Console.WriteLine("Разработайте программу-калькулятор,в которой можно выбрать действия для двух выбранных чисел\nНажмите на любой символ чтобы продолжить");
                    Console.ReadLine();
                    WriteNumber();
                    break;
                case "3":
                    Console.WriteLine("Разработайте программу для конвертации температуры между градусами цельсия,Кельвина,Фаренгейта\nНажмите на любой символ чтобы продолжить");
                    Console.ReadLine();
                    TemperatureConversion();

                    break;
                case "4":
                    Console.WriteLine("Разработайте программу,которая позволяет определить имя файла (с расширение) по введённому пути\nНажмите на любой символ чтобы продолжить");
                    Console.ReadLine();
                    FileName();

                    break;
                case "5":
                    Console.WriteLine("Разработайте программу для нахождения самого длинного слова в предложении\nНажмите на любой символ чтобы продолжить");
                    Console.ReadLine();
                    TheLongestOne();

                    break;
                case "6":
                    Console.WriteLine("Разработайте программу, которая может  перемножить два массива значений\nНажми на любой символ чтобы продолжить ");
                    Console.ReadLine();
                    CycleMultiplication();

                    break;
                case "7":
                    Console.WriteLine("Разработайте программу которая может найти максимальное и минимальное число из пяти введёных\nНажми на любой символ чтобы продолжить ");
                    Console.ReadLine();
                    MaxNumber();


                    break;
                case "8":
                    Console.WriteLine("Разработайте программу которая выводит пирамиду из чисел из количества уровне введёных пользователем\nНажми на любой символ чтобы продолжить ");
                    Console.ReadLine();
                    Piramid();

                    break;
                case "9":
                    Console.WriteLine("Напечатайте полную таблицу умножения в консоли\nНажми на любой символ чтобы продолжить");
                    Console.ReadLine();
                    Tablemultiply();


                    break;

                case "10":
                    Console.WriteLine("Напечатайте полную таблицу возведения в степень \nНажми на любой символ чтобы продолжить");
                    Console.ReadLine();
                    Tablecvuare();

                    break;
                default:
                    Console.WriteLine("Выбор неопределён");
                    Console.ReadLine();
                    Menu();

                    break;



            }
            static void Back() 
            {
                Console.WriteLine("Вернуться в начало? y/n");
                 string a = (Console.ReadLine());
                if (a == "y" ^ a == "н")
                {
                    Menu();
                }
                else if (a == "n" ^ a == "т")
                {
                    Environment.Exit(0);
                }
                else 
                {
                    Environment.Exit(0);
                }
                
            
            }
            static void Middle()
            {
                Console.Clear();
                Console.WriteLine("Введите 4 числа");
                double a;
                a = Convert.ToDouble(Console.ReadLine());
                double b;
                b = Convert.ToDouble(Console.ReadLine());
                double c;
                c = Convert.ToDouble(Console.ReadLine());
                double d;
                d = Convert.ToDouble(Console.ReadLine());
                double srednee = (a + b + c + d);
                double znachenie = (srednee / 4);
                Console.WriteLine(znachenie);
                Back();

            }
            static void WriteNumber()
            {
                Console.Clear();
                Console.WriteLine("Что вы хотите сделать?\n 1)сложение\n 2)вычитание\n 3)умножение\n 4)деление\n 5)возвести в степень \n 6)перевести в систему исчисления \n 7)найти факториал \n 8)Найти остаток от деления");
                string choice = "";
                choice = Console.ReadLine();
                Console.Clear();


                if (choice == "5" ^ choice == "6" ^ choice == "7" ^choice == "8")
                {
                    switch (choice)
                    {
                        case "5":
                            Console.WriteLine("Напиши число которое хочешь возвести");
                            Double a;
                            a = Inicial();
                            Console.WriteLine("Напиши степень в которую хочешь возвести число");
                            double b;
                            b = Inicial();
                            double powResult = 1;
                            for (int i = 1; i <= b; i++)
                            {
                                powResult *= a;
                            }
                            Console.WriteLine(powResult);
                            YesNo();
                            break;

                        case "6":

                            Console.WriteLine("Напиши число которое хочешь перевести");
                            int n = Convert.ToInt32(Inicial());
                            Console.WriteLine("Напиши систему в которую хочешь перевести");
                            int m = Convert.ToInt32(Inicial());
                            string s = "";
                            while (n > 0)
                            {
                                s = Convert.ToString(n % m) + s;
                                n /= m;
                            }
                            Console.WriteLine(s);
                            YesNo();
                            break;
                        case "7":
                            Console.WriteLine("Введите число у которого хотите найти факториал.");
                            double h;
                            h = Inicial();
                            int sum = 1;
                            for (int i = 1; i <= h; i++)
                            {
                                sum *= i;
                            }
                            Console.WriteLine(sum);
                            YesNo();
                            break;
                        case "8":
                            Console.WriteLine("Введите число которое хотите поделить а затем число на которое будете делить и увидете остаток от деления");
                            double o;
                            o = Inicial();
                            double p;
                            p = Inicial();
                            double ostatok = o % p;
                            Console.WriteLine(ostatok);
                          break;
                        default:
                            Console.WriteLine("Выбор неопределён");
                            Console.ReadLine();
                            Back();
                            break;

                    }
                }
                else if (choice == "1" ^ choice == "2" ^ choice == "3" ^ choice == "4")
                {
                    Console.WriteLine("Напиши 2 числа");
                    Double a;
                    a = Inicial();
                    double b;
                    b = Inicial();
                    switch (choice)
                    {
                        case "1":
                            Console.WriteLine($"{(a + b)} вот твоё число");
                            YesNo();
                            break;

                        case "2":
                            Console.WriteLine($"{(a - b)} вот твоё число ");
                            YesNo();
                            break;
                        case "3":
                            Console.WriteLine($"{(a * b)} вот твоё число");
                            YesNo();
                            break;
                        case "4":
                            if (b == 0) { Console.WriteLine("Извини друг, на ноль делить нельзя. Ещё раз так сделаешь я оффну систему)"); }
                            else
                            {
                                Console.WriteLine($"{(a / b)} вот твоё число");
                            }
                            YesNo();
                            break;
                        default:
                            Console.WriteLine("Выбор неопределён");
                            Console.ReadLine();
                            YesNo();
                            break;

                    }
                }
                else
                {
                    Console.WriteLine("Вы ввели неверное значение");
                    Console.ReadLine();
                    Back();


                }

                void YesNo()
                {
                    Console.WriteLine("хочешь попробовать ещё раз? y/n");
                    string yesNo = "";
                    yesNo = Console.ReadLine();
                    if (yesNo == "y")
                    {
                        WriteNumber();
                    }
                    else
                    {
                        Back();
                    }

                }


                static Double Inicial()
                {
                    Double a = Convert.ToDouble(Console.ReadLine());

                    return a;
                }
            }
            static void TemperatureConversion()
            {
                Console.Clear();
                Console.WriteLine("Выберите шкалу вводимой температуры: \n 1)Цельсия \n 2)Кельвин \n 3)Фаренгейт");
                int choice = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Напиши показатель температуры");
                switch (choice)
                {

                    case 1:

                        C();



                        break;
                    case 2:

                        K();



                        break;
                    case 3:

                        F();


                        break;

                    default:
                        Console.WriteLine("Ты не выбрал");
                        Console.ReadLine();
                        Environment.Exit(0);
                        break;



                }
                double Temperature()
                {
                    double numder = Convert.ToDouble(Console.ReadLine());
                    return numder;

                }
                void C()
                {
                    double h = Temperature();
                    Console.WriteLine("Выбери тип шкалы для конвертации \n 1)Цельсия \n 2)Кельвин \n 3)Фаренгейт");
                    int choiceC = Convert.ToInt32(Console.ReadLine());
                    switch (choiceC)
                    {
                        case 1:

                            Console.WriteLine(h);



                            break;
                        case 2:

                            Console.WriteLine(h + 273.15);



                            break;
                        case 3:

                            Console.WriteLine((h * 9 / 5) + 32);


                            break;

                        default:
                            Console.WriteLine("Ты не выбрал");
                            Console.ReadLine();
                            Environment.Exit(0);
                            break;



                    }
                    Console.WriteLine("Попробовать ещё раз?\n y/n ");
                    string exit = (Console.ReadLine());
                    if (exit == "y")
                    {
                        TemperatureConversion();
                    }
                    else if (exit == "n")
                    {
                        Environment.Exit(0);

                    }
                    else
                    {
                        Environment.Exit(0);


                    }





                }
                void F()
                {
                    double h = Temperature();
                    Console.WriteLine("Выбери тип шкалы для конвертации \n 1)Цельсия \n 2)Кельвин \n 3)Фаренгейт");
                    int choiceF = Convert.ToInt32(Console.ReadLine());

                    switch (choiceF)
                    {
                        case 1:

                            Console.WriteLine((h - 32) * 5 / 9);


                            break;
                        case 2:

                            Console.WriteLine((h - 32) * 5 / 9 + 273.15);


                            break;
                        case 3:

                            Console.WriteLine(h);


                            break;

                        default:
                            Console.WriteLine("Ты не выбрал");
                            Console.ReadLine();
                            Environment.Exit(0);
                            break;

                    }
                    Console.WriteLine("Попробовать ещё раз?\n y/n ");
                    string exit = (Console.ReadLine());
                    if (exit == "y")
                    {
                        TemperatureConversion();
                    }
                    else if (exit == "n")
                    {
                        Environment.Exit(0);

                    }
                    else
                    {
                        Environment.Exit(0);


                    }


                }
                void K()
                {
                    double h = Temperature();
                    Console.WriteLine("Выбери тип шкалы для конвертации \n 1)Цельсия \n 2)Кельвин \n 3)Фаренгейт");
                    int ChoiceK = Convert.ToInt32(Console.ReadLine());
                    switch (ChoiceK)
                    {
                        case 1:

                            Console.WriteLine(h - 272.15);


                            break;
                        case 2:

                            Console.WriteLine(h);


                            break;
                        case 3:

                            Console.WriteLine((h - 273.15) * 9 / 5 + 32);


                            break;

                        default:
                            Console.WriteLine("Ты не выбрал");
                            Console.ReadLine();
                            Environment.Exit(0);
                            break;




                    }
                    Console.WriteLine("Попробовать ещё раз?\n y/n ");
                    string exit = (Console.ReadLine());
                    if (exit == "y" ^ exit == "н")
                    {
                        TemperatureConversion();
                    }
                    else if (exit == "n" ^ exit == "т")
                    {
                        Environment.Exit(0);

                    }
                    else
                    {
                        Environment.Exit(0);


                    }


                }

            }
            static void FileName()
            {
                Console.Clear();
                Console.WriteLine("Введите путь к файлу");
                string way = Console.ReadLine();
                string[] parts = way.Split(new char[] { '\\' }, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length > 0)
                {
                    string fileName = parts[parts.Length - 1];
                    Console.WriteLine("Имя файла " + fileName);
                    Console.ReadLine();
                    Back();
                }
                else
                {
                    Console.WriteLine("Путь не содержит имени файла");
                    Console.ReadLine();
                    Back();
                };

            }
            static void TheLongestOne()
            {
                Console.Clear();
                Console.WriteLine("Введите предложение");
                string task = Console.ReadLine();
                string[] words = task.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                string longestWord = "";
                foreach (string word in words)
                {
                    if (word.Length > longestWord.Length)
                    {
                        longestWord = word;
                    }
                }
                if (longestWord.Length > 0)
                {
                    Console.WriteLine("Самое длинное слово " + longestWord);
                    Console.ReadLine();
                    Back();
                }
                else
                {
                    Console.WriteLine("Нет слов в предложении");
                    Console.ReadLine();
                    Back();
                }
            }
            static void CycleMultiplication()
            {
                Console.Clear();
                Console.WriteLine("Введите сколько чисел будет в массиве");
                int size = Convert.ToInt32(Console.ReadLine());
                int[] arrayOne = new int[size];
                int[] arrayTwo = new int[size];
                Console.WriteLine("Введите через пробел числа первого массива");
                string[] inputOne = Console.ReadLine().Split(' ');
                if (inputOne.Length != size)
                {
                    Console.WriteLine("Ты не правильно ввёл числа");
                    Console.ReadLine();
                    CycleMultiplication();
                }
                else
                {
                    for (int i = 0; i < size; i++)
                    {
                        arrayOne[i] = Convert.ToInt32(inputOne[i]);
                    }
                }
                Console.WriteLine("Введите через пробел элементы второго массива");
                string[] inputTwo = Console.ReadLine().Split(' ');
                if (inputTwo.Length != size)
                {
                    Console.WriteLine("Ты не правильно ввёл числа");
                    Console.ReadLine();
                    CycleMultiplication();
                }
                else
                {
                    for (int i = 0; i < size; i++)
                    {
                        arrayTwo[i] = Convert.ToInt32(inputTwo[i]);
                    }
                }
                int[] result = new int[size];
                for (int i = 0; i < size; i++)
                {
                    result[i] = arrayOne[i] * arrayTwo[i];
                }
                Console.WriteLine("Результат");
                foreach (int value in result)
                {
                    Console.Write(value + " ");

                }
                Console.ReadLine();
                Back();



            }
            static void MaxNumber()
            {
                Console.Clear();
                Console.WriteLine("Введи пять чисел через пробел");
                string Numbers = Console.ReadLine();
                string[] NumbersParts = Numbers.Split(new char[] { ' ' });
                string biggestNum = "-9999999";
                string minNum = "999999999";
                if (NumbersParts.Length != 5)
                {
                    Console.WriteLine("Ты неправильно ввел");
                    Console.ReadLine();
                    MaxNumber();

                }
                else
                {
                    foreach (string value in NumbersParts)
                    {

                        if (Convert.ToDouble(value) > Convert.ToDouble(biggestNum))
                        {
                            biggestNum = value;


                        }
                        if (Convert.ToDouble(value) < Convert.ToDouble(minNum))
                        {

                            minNum = value;
                        }

                    }
                    Console.WriteLine($"biggest {biggestNum}");
                    Console.WriteLine(($"smallest {minNum}"));
                    Console.ReadLine();
                    Back();


                }
            }
            static void Piramid()
            {
                Console.WriteLine("Введите число ступеней пирамиды");
                int a = Convert.ToInt32(Console.ReadLine());
                string b = "";
                for (int i = 0; i < a; i++)
                {
                    b += i + 1;
                    Console.WriteLine(b);
                }
                Console.ReadLine();
                Back();




            }
            static void Tablemultiply()
            {                
                for (int i = 0; i <= 9; i++)
                {
                    for(int j = 0;  j <= 9; j++)
                    {
                       

                        Console.WriteLine($"{j} * {i} = {j*i}\t");
                        
                    }
                    Console.WriteLine();

                }
                Console.ReadLine();
                Back();
            }
            static void Tablecvuare() 
            {
                for (int i = 0; i <= 9; i++)
                {
                    for (int j = 0; j <= 9; j++)
                    {
                        Console.Write($"{i}^{j} = {Math.Pow(i, j)}|");
                    }
                    Console.WriteLine();

                }
                Console.ReadLine();
                Back();

            }
        }




    }
}





